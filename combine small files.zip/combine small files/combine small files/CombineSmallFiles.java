import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.Date;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class CombineSmallFiles {
    public static void main(String[] args) {
        // Define input and output directories
        Path inputDir = Paths.get("C:/input");
        Path outputFile = Paths.get("C:/output/combined.seq");

        try {
            // Create output directory if it doesn't exist
            Files.createDirectories(outputFile.getParent());

            // Combine files into one
            try (BufferedWriter writer = Files.newBufferedWriter(outputFile)) {
                Files.list(inputDir).forEach(file -> {
                    try (BufferedReader reader = Files.newBufferedReader(file)) {
                        writer.write("File: " + file.getFileName() + "\n");
                        String line;
                        while ((line = reader.readLine()) != null) {
                            writer.write(line + "\n");
                        }
                        writer.write("\n");
                    } catch (IOException e) {
                        System.err.println("Error reading file: " + file.getFileName());
                    }
                });
            }
            System.out.println("Files combined successfully!");

            // Save metadata to both SQL Server and MongoDB
            saveToSQLServer("combined.seq", outputFile.toString());
            saveToMongoDB("combined.seq", outputFile.toString());

        } catch (NoSuchFileException e) {
            System.err.println("Input directory does not exist. Please create it and add files.");
        } catch (IOException e) {
            System.err.println("An error occurred while combining files: " + e.getMessage());
        }
    }

    private static void saveToSQLServer(String fileName, String filePath) {
        // Connection string for Windows Authentication
        String url = "jdbc:sqlserver://localhost:1433;databaseName=FileMetadataDB;encrypt=true;trustServerCertificate=true;integratedSecurity=true";

        // SQL queries to create database and table if they don't exist
        String createDatabaseQuery = "IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'FileMetadataDB') BEGIN CREATE DATABASE FileMetadataDB END";
        String createTableQuery = "IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='OutputFiles' AND xtype='U') BEGIN CREATE TABLE OutputFiles (" +
                                  "ID INT IDENTITY(1,1) PRIMARY KEY, " +
                                  "FileName NVARCHAR(255), " +
                                  "FilePath NVARCHAR(MAX), " +
                                  "Timestamp DATETIME, " +
                                  "Description NVARCHAR(MAX)) END";
        String insertQuery = "INSERT INTO OutputFiles (FileName, FilePath, Timestamp, Description) VALUES (?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(url);
             Statement statement = connection.createStatement()) {

            // Create database and table if they don't exist
            statement.execute(createDatabaseQuery);
            statement.execute(createTableQuery);

            // Insert data into the table
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, fileName);
                preparedStatement.setString(2, filePath);
                preparedStatement.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                preparedStatement.setString(4, "Combined output file");
                preparedStatement.executeUpdate();
                System.out.println("Output saved to SQL Server!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to save to SQL Server: " + e.getMessage());
        }
    }

    private static void saveToMongoDB(String fileName, String filePath) {
        String connectionString = "mongodb://localhost:27017";
        try (MongoClient client = MongoClients.create(connectionString)) {
            MongoDatabase database = client.getDatabase("FileMetadataDB");
            MongoCollection<Document> collection = database.getCollection("OutputFiles");

            Document document = new Document("FileName", fileName)
                    .append("FilePath", filePath)
                    .append("Timestamp", new Date())
                    .append("Description", "Combined output file");

            collection.insertOne(document);
            System.out.println("Output saved to MongoDB!");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to save to MongoDB: " + e.getMessage());
        }
    }
}