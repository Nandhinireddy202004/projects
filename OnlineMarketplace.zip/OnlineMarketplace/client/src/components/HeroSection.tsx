import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";

interface HeroSectionProps {
  onShopNow: () => void;
}

export function HeroSection({ onShopNow }: HeroSectionProps) {
  return (
    <section className="bg-gradient-to-r from-primary to-blue-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Premium Quality Products</h2>
            <p className="text-xl mb-8 text-blue-100">
              Discover our curated collection of the finest products, carefully selected for quality and style.
            </p>
            <Button
              onClick={onShopNow}
              className="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
            >
              Shop Now
            </Button>
          </div>
          <div className="hidden md:block">
            <div className="bg-white bg-opacity-10 rounded-2xl p-8 backdrop-blur-sm flex items-center justify-center">
              <ShoppingBag className="h-32 w-32 text-white opacity-50" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
