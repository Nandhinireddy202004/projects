import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";

interface Category {
  id: number;
  name: string;
  slug: string;
}

interface CategoryNavigationProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export function CategoryNavigation({ selectedCategory, onCategoryChange }: CategoryNavigationProps) {
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8 overflow-x-auto py-4">
          <Button
            variant="ghost"
            onClick={() => onCategoryChange("all")}
            className={`whitespace-nowrap pb-2 ${
              selectedCategory === "all"
                ? "text-primary font-medium border-b-2 border-primary"
                : "text-gray-600 hover:text-primary transition-colors"
            }`}
          >
            All Products
          </Button>
          {categories.map((category) => (
            <Button
              key={category.id}
              variant="ghost"
              onClick={() => onCategoryChange(category.id.toString())}
              className={`whitespace-nowrap pb-2 ${
                selectedCategory === category.id.toString()
                  ? "text-primary font-medium border-b-2 border-primary"
                  : "text-gray-600 hover:text-primary transition-colors"
              }`}
            >
              {category.name}
            </Button>
          ))}
        </div>
      </div>
    </nav>
  );
}
