import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { CategoryNavigation } from "@/components/CategoryNavigation";
import { HeroSection } from "@/components/HeroSection";
import { ProductGrid } from "@/components/ProductGrid";
import { Footer } from "@/components/Footer";
import { CartProvider } from "@/contexts/CartContext";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const handleShopNow = () => {
    const productsSection = document.getElementById("products");
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // Reset category when searching
    if (query) {
      setSelectedCategory("all");
    }
  };

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    // Clear search when changing category
    setSearchQuery("");
  };

  return (
    <CartProvider>
      <div className="min-h-screen bg-gray-50">
        <Header onSearch={handleSearch} />
        <CategoryNavigation
          selectedCategory={selectedCategory}
          onCategoryChange={handleCategoryChange}
        />
        <HeroSection onShopNow={handleShopNow} />
        <ProductGrid
          selectedCategory={selectedCategory}
          searchQuery={searchQuery}
        />
        <Footer />
      </div>
    </CartProvider>
  );
}
