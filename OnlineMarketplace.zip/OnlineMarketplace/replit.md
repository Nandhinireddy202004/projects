# Replit.md

## Overview

This is a modern e-commerce web application built with a React frontend and Express.js backend. The application provides a complete shopping experience with user authentication, product browsing, cart management, and order processing. It uses Replit Auth for authentication and PostgreSQL with Drizzle ORM for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack architecture with clear separation between frontend and backend:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth with OpenID Connect
- **UI Components**: Radix UI with shadcn/ui components and Tailwind CSS
- **State Management**: React Query for server state, React Context for cart state

## Key Components

### Frontend Architecture
- **Client-side routing**: Using Wouter for lightweight routing
- **Component library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State management**: 
  - React Query for server state caching and synchronization
  - React Context for cart state management
- **Form handling**: React Hook Form with Zod validation

### Backend Architecture
- **API server**: Express.js with TypeScript
- **Database layer**: Drizzle ORM with PostgreSQL
- **Authentication**: Passport.js with Replit Auth strategy
- **Session management**: Express sessions with PostgreSQL storage
- **API structure**: RESTful endpoints for products, categories, cart, and orders

### Database Schema
The application uses the following main entities:
- **Users**: Stores user authentication data (required for Replit Auth)
- **Categories**: Product categorization
- **Products**: Product catalog with images, pricing, and ratings
- **Cart Items**: User shopping cart management
- **Orders & Order Items**: Order processing and history
- **Sessions**: Session storage (required for Replit Auth)

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, sessions stored in PostgreSQL
2. **Product Browsing**: Products fetched from database, cached via React Query
3. **Cart Management**: Cart operations sync with backend, state managed via React Context
4. **Order Processing**: Cart items converted to orders with shipping information
5. **Real-time Updates**: React Query handles cache invalidation and optimistic updates

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight client-side routing

### UI Dependencies
- **@radix-ui/react-***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library

### Authentication Dependencies
- **openid-client**: OpenID Connect client
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

The application is configured for Replit deployment with:

- **Development**: `npm run dev` - Runs development server with hot reload
- **Build**: `npm run build` - Creates production build
- **Production**: `npm start` - Serves built application
- **Database**: Uses Replit's PostgreSQL database via DATABASE_URL environment variable

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `REPL_ID`: Replit application identifier
- `ISSUER_URL`: OpenID Connect issuer URL

### Build Process
- Frontend built with Vite, outputs to `dist/public`
- Backend built with esbuild, outputs to `dist/index.js`
- Static files served by Express in production
- Development uses Vite dev server with middleware integration

The application is designed to work seamlessly in the Replit environment with proper authentication integration and database connectivity.