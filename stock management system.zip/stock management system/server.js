const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const PORT = 3000;

// PostgreSQL Configuration
const pool = new Pool({
    user: 'postgres',       // Replace with your PostgreSQL username
    host: 'localhost',           // Database host
    database: 'postgres', // Database name
    password: '1234',   // Your PostgreSQL password
    port: 5432                   // Default PostgreSQL port
});

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Automatically Create Tables and Add Default Data
const initializeDatabase = async () => {
    try {
        // Create Users Table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(50) NOT NULL,
                password VARCHAR(50) NOT NULL,
                role VARCHAR(10) NOT NULL
            );
        `);

        // Create Stocks Table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS stocks (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                quantity INT NOT NULL,
                price NUMERIC(10, 2) NOT NULL
            );
        `);

        // Insert Default Users
        await pool.query(`
            INSERT INTO users (username, password, role)
            VALUES 
                ('admin', 'admin', 'admin'),
                ('user', 'user', 'user')
            ON CONFLICT DO NOTHING;
        `);

        console.log("Database initialized successfully!");
    } catch (err) {
        console.error("Error initializing the database:", err);
    }
};

// Initialize Database on Server Start
initializeDatabase();

// API to Add Stock
app.post('/add-stock', async (req, res) => {
    const { name, quantity, price } = req.body;
    try {
        const result = await pool.query(
            'INSERT INTO stocks (name, quantity, price) VALUES ($1, $2, $3) RETURNING *',
            [name, quantity, price]
        );
        res.json({ success: true, message: 'Stock added successfully!', stock: result.rows[0] });
    } catch (err) {
        console.error('Error adding stock:', err);
        res.status(500).json({ success: false, message: 'Server error!' });
    }
});
// API to View Stocks
app.get('/view-stock', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM stocks');
        res.json({ success: true, stocks: result.rows });
    } catch (err) {
        console.error('Error fetching stocks:', err);
        res.status(500).json({ success: false, message: 'Server error!' });
    }
});

// Start the Server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});